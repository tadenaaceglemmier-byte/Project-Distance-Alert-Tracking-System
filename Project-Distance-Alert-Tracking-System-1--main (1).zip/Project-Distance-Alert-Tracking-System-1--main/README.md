# Distance Alert Tracking System

Waypoint is a Django application for private, browser-based distance tracking. A signed-in user saves destinations, configures distance thresholds, and starts a tracking session. While a session is active, the browser Geolocation API sends periodic fixes to Django. The server calculates the great-circle distance, records location history, and creates a notification the first time each armed threshold is entered. An alert rearms after the user moves more than 15% beyond its threshold.

## Requirements

- Python 3.10 or later
- Django 5.2+
- MySQL 8.0+ for a MySQL deployment, or SQLite for local development
- A modern browser with location access; browser geolocation requires HTTPS in production (localhost is allowed for development)

The map uses Leaflet and OpenStreetMap tiles. Bootstrap and the font families load from public CDNs, so the browser needs network access for those assets and map tiles.

## Local Setup (Windows PowerShell)

From the folder containing `manage.py`:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

Open `http://127.0.0.1:8000/`, create an account, add a destination using decimal latitude and longitude, add one or more alert thresholds, then start tracking and allow browser location access. Use `/admin/` to manage users and inspect destinations, sessions, location history, and alert history.

The default database is SQLite and needs no additional setup. The development secret key is only a local fallback; configure a private key before deployment.

## MySQL Configuration

Create a UTF-8 database and a dedicated database user with privileges limited to this database:

```sql
CREATE DATABASE distance_alerts CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'distance_alerts_app'@'localhost' IDENTIFIED BY 'use-a-unique-secret';
GRANT ALL PRIVILEGES ON distance_alerts.* TO 'distance_alerts_app'@'localhost';
```

Set these variables in the deployment environment before running Django commands. In PowerShell, for a local session:

```powershell
$env:DB_ENGINE = "mysql"
$env:DB_NAME = "distance_alerts"
$env:DB_USER = "distance_alerts_app"
$env:DB_PASSWORD = "your-database-password"
$env:DB_HOST = "127.0.0.1"
$env:DB_PORT = "3306"
$env:DJANGO_SECRET_KEY = "generate-a-long-random-secret-outside-source-control"
$env:DJANGO_DEBUG = "false"
$env:DJANGO_ALLOWED_HOSTS = "your-domain.example"
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

Use a secret manager or protected environment configuration for credentials. Do not commit credentials. In production, serve the site over HTTPS and configure the reverse proxy and allowed host names appropriately.

## Data and Privacy

- Destinations, sessions, alerts, location points, and notifications are linked to an account; application views only return the signed-in user's records.
- Location updates are accepted only from authenticated users with an active session. Coordinates and accuracy are range-checked on the server.
- The browser stops sharing when tracking is stopped or GPS reports an error. Reloading an active dashboard resumes browser tracking for that session.
- Deleting a destination permanently deletes its sessions and associated location and notification history.
- Staff users can inspect records through Django admin. Limit staff access to trusted operators.

## Models

- `UserProfile`: optional phone and account profile data.
- `Destination`: an owner's named WGS84 coordinate pair.
- `TrackingSession`: a destination visit with a portable unique active-owner guard.
- `LocationHistory`: validated location fixes and server-calculated distance.
- `DistanceAlert`: a unique threshold per destination with enabled/armed state.
- `NotificationHistory`: recorded alert events for a tracking session.

The initial schema and follow-up portability migration are in `datsback/migrations/`.

## Verification

```powershell
python manage.py check
python manage.py test datsback
```

Tests cover distance calculation, authenticated access, account isolation, coordinate validation, registration, and alert triggering/re-arming.