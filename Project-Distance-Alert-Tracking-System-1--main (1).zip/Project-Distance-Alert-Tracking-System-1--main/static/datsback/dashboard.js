(() => {
  const form = document.getElementById("tracking-form");
  const mapElement = document.getElementById("tracking-map");
  if (!form || !mapElement || !window.L) return;

  const csrfToken = form.querySelector("[name=csrfmiddlewaretoken]").value;
  const destinationSelect = document.getElementById("destination-select");
  const trackButton = document.getElementById("track-button");
  const statusLabel = document.getElementById("tracking-status-label");
  const indicator = document.getElementById("tracking-indicator");
  const permissionNote = document.getElementById("permission-note");
  const soundToggle = document.getElementById("sound-toggle");
  let watchId = null;
  let destinationMarker = null;
  let currentMarker = null;
  let lastSentAt = 0;
  let isActive = Boolean(trackButton && trackButton.classList.contains("stop-button"));

  const map = L.map(mapElement, { zoomControl: false }).setView([20, 0], 2);
  L.control.zoom({ position: "bottomright" }).addTo(map);
  const tileLayer = L.tileLayer("https://tile.openstreetmap.de/{z}/{x}/{y}.png", {
    maxZoom: 19,
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap</a> contributors',
  }).addTo(map);
  tileLayer.on("tileerror", () => {
    permissionNote.textContent = "Map tiles could not be loaded. Check your internet connection and reload the page.";
  });

  const destinationCoordinates = () => {
    if (!destinationSelect || !destinationSelect.selectedOptions.length) return null;
    const option = destinationSelect.selectedOptions[0];
    return { lat: Number(option.dataset.lat), lng: Number(option.dataset.lng), name: option.textContent.trim() };
  };

  function drawDestination() {
    const point = destinationCoordinates();
    if (!point || !Number.isFinite(point.lat) || !Number.isFinite(point.lng)) return;
    if (destinationMarker) map.removeLayer(destinationMarker);
    destinationMarker = L.circleMarker([point.lat, point.lng], {
      radius: 8, color: "#fb6542", weight: 3, fillColor: "#fffaf5", fillOpacity: 1,
    }).addTo(map).bindTooltip(Object.assign(document.createElement("span"), { textContent: point.name }), { direction: "top", offset: [0, -8] });
    document.getElementById("map-destination-name").textContent = point.name;
    if (!currentMarker) map.setView([point.lat, point.lng], 13);
    else map.fitBounds(L.latLngBounds([currentMarker.getLatLng(), [point.lat, point.lng]]), { padding: [48, 48], maxZoom: 15 });
  }

  async function post(url, values = {}) {
    const body = new URLSearchParams({ ...values, csrfmiddlewaretoken: csrfToken });
    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded", "X-CSRFToken": csrfToken },
      body,
      credentials: "same-origin",
    });
    const data = await response.json();
    if (!response.ok || !data.ok) throw new Error(data.error || "The request could not be completed.");
    return data;
  }

  function setStatus(active, label) {
    isActive = active;
    indicator.classList.toggle("is-live", active);
    statusLabel.textContent = label || (active ? "TRACKING LIVE" : "STANDING BY");
    if (trackButton) {
      trackButton.classList.toggle("stop-button", active);
      trackButton.innerHTML = active ? '<span aria-hidden="true">■</span> Stop tracking' : '<span aria-hidden="true">◎</span> Start tracking';
      if (destinationSelect) destinationSelect.disabled = active;
    }
  }

  function showBanner(text) {
    const banner = document.createElement("div");
    banner.className = "distance-notice";
    banner.setAttribute("role", "alert");
    banner.innerHTML = '<span class="notice-icon" aria-hidden="true">!</span><span></span><button type="button" aria-label="Dismiss alert">×</button>';
    banner.querySelector("span:nth-child(2)").textContent = text;
    banner.querySelector("button").addEventListener("click", () => banner.remove());
    document.body.append(banner);
    window.setTimeout(() => banner.remove(), 8000);
  }

  function playAlertSound() {
    if (!soundToggle.checked) return;
    try {
      const context = new AudioContext();
      const oscillator = context.createOscillator();
      const gain = context.createGain();
      oscillator.type = "sine";
      oscillator.frequency.setValueAtTime(740, context.currentTime);
      oscillator.frequency.setValueAtTime(980, context.currentTime + 0.13);
      gain.gain.setValueAtTime(0.12, context.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, context.currentTime + 0.38);
      oscillator.connect(gain).connect(context.destination);
      oscillator.start();
      oscillator.stop(context.currentTime + 0.4);
      oscillator.addEventListener("ended", () => context.close());
    } catch (error) {
      console.warn("Alert sound could not be played.", error);
    }
  }

  async function sendLocation(position) {
    const { latitude, longitude, accuracy } = position.coords;
    currentMarker = currentMarker || L.circleMarker([latitude, longitude], {
      radius: 7, color: "#137b69", weight: 3, fillColor: "#e4f3e8", fillOpacity: 1,
    }).addTo(map).bindTooltip("Your location", { direction: "top", offset: [0, -8] });
    currentMarker.setLatLng([latitude, longitude]);
    if (destinationMarker) {
      map.fitBounds(L.latLngBounds([currentMarker.getLatLng(), destinationMarker.getLatLng()]), { padding: [48, 48], maxZoom: 15 });
    } else {
      map.setView([latitude, longitude], 15);
    }
    document.getElementById("coordinates-value").textContent = `${latitude.toFixed(5)}, ${longitude.toFixed(5)}`;
    document.getElementById("accuracy-value").textContent = `±${Math.round(accuracy)} m`;
    permissionNote.textContent = "GPS location updates while tracking is active.";

    try {
      const result = await post(form.dataset.locationUrl, { latitude, longitude, accuracy });
      const distance = result.distance_meters;
      document.getElementById("distance-value").innerHTML = `${Math.round(distance).toLocaleString()}<span>m</span>`;
      document.getElementById("distance-sub").textContent = distance >= 1000
        ? `${(distance / 1000).toFixed(2)} km to destination`
        : `${Math.round(distance)} meters to destination`;
      for (const alert of result.alerts) {
        showBanner(alert.message);
        playAlertSound();
      }
    } catch (error) {
      permissionNote.textContent = error.message;
      showBanner(error.message);
    }
  }

  function onLocationError(error) {
    if (!isActive && watchId === null) return;
    const message = error.code === 1
      ? "Location permission was denied. Allow location access in your browser to track."
      : error.code === 2
        ? "Your location is unavailable. Check GPS or network access and try again."
        : "GPS timed out. Move to a clearer area or try again.";
    permissionNote.textContent = message;
    setStatus(false, "LOCATION UNAVAILABLE");
    post(form.dataset.stopUrl).catch(() => {});
    showBanner(message);
    if (watchId !== null) navigator.geolocation.clearWatch(watchId);
    watchId = null;
  }

  function beginWatching() {
    if (!navigator.geolocation) {
      onLocationError({ code: 2 });
      return;
    }
    watchId = navigator.geolocation.watchPosition((position) => {
      const currentTime = Date.now();
      if (currentTime - lastSentAt < 4000) return;
      lastSentAt = currentTime;
      sendLocation(position);
    }, onLocationError, { enableHighAccuracy: true, maximumAge: 3000, timeout: 20000 });
  }

  if (trackButton) {
    trackButton.addEventListener("click", async () => {
      trackButton.disabled = true;
      try {
        if (isActive) {
          await post(form.dataset.stopUrl);
          if (watchId !== null) navigator.geolocation.clearWatch(watchId);
          watchId = null;
          setStatus(false);
          permissionNote.textContent = "Location sharing has stopped.";
        } else {
          const point = destinationCoordinates();
          if (!point) return;
          await post(form.dataset.startUrl, { destination_id: destinationSelect.value });
          drawDestination();
          setStatus(true);
          permissionNote.textContent = "Waiting for a GPS fix…";
          beginWatching();
        }
      } catch (error) {
        permissionNote.textContent = error.message;
        showBanner(error.message);
      } finally {
        trackButton.disabled = false;
      }
    });
  }

  if (destinationSelect) destinationSelect.addEventListener("change", drawDestination);
  document.getElementById("locate-button").addEventListener("click", () => {
    if (currentMarker) map.setView(currentMarker.getLatLng(), 16);
    else if (destinationMarker) map.setView(destinationMarker.getLatLng(), 14);
  });

  drawDestination();
  if (isActive) beginWatching();

  // Tap-and-Drag Destination Pin
  const destinationModal = document.getElementById("destination-modal");
  const destinationPickerElement = document.getElementById("destination-picker-map");
  const destinationForm = document.getElementById("destination-form");
  let destinationPicker = null;
  let destinationPickerMarker = null;

  if (destinationModal && destinationPickerElement && destinationForm && window.L) {
    const latitudeInput = destinationForm.querySelector("[name=latitude]");
    const longitudeInput = destinationForm.querySelector("[name=longitude]");
    const pickerHint = document.getElementById("destination-picker-hint");

    function placePin(lat, lng) {
      latitudeInput.value = Number(lat).toFixed(7);
      longitudeInput.value = Number(lng).toFixed(7);

      if (destinationPickerMarker) destinationPicker.removeLayer(destinationPickerMarker);
      destinationPickerMarker = L.marker([lat, lng], {
        draggable: true,
        keyboard: true,
        title: "Destination pin",
      }).addTo(destinationPicker);

      destinationPickerMarker.on("dragend", (event) => {
        const point = event.target.getLatLng();
        latitudeInput.value = point.lat.toFixed(7);
        longitudeInput.value = point.lng.toFixed(7);
        pickerHint.textContent = "Pin moved. Ready to save.";
      });

      pickerHint.textContent = "Pin placed. Tap another spot or drag the pin.";
      pickerHint.classList.remove("form-hint-error");
    }

    destinationModal.addEventListener("shown.bs.modal", () => {
      if (!destinationPicker) {
        destinationPicker = L.map(destinationPickerElement, {
          zoomControl: true,
          doubleClickZoom: false,
        }).setView([10.3157, 123.8854], 12);

        L.tileLayer("https://tile.openstreetmap.de/{z}/{x}/{y}.png", {
          maxZoom: 19,
          attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap</a> contributors',
        }).addTo(destinationPicker);

        destinationPicker.on("click", (event) => placePin(event.latlng.lat, event.latlng.lng));
      }
      destinationPicker.invalidateSize();
    });

    destinationForm.addEventListener("submit", (event) => {
      if (!latitudeInput.value || !longitudeInput.value) {
        event.preventDefault();
        pickerHint.textContent = "Tap the map to place a pin first.";
        pickerHint.classList.add("form-hint-error");
      }
    });

    destinationModal.addEventListener("hidden.bs.modal", () => {
      destinationForm.reset();
      latitudeInput.value = "";
      longitudeInput.value = "";
      pickerHint.textContent = "Tap a location on the map.";
      pickerHint.classList.remove("form-hint-error");
      if (destinationPickerMarker) {
        destinationPicker.removeLayer(destinationPickerMarker);
        destinationPickerMarker = null;
      }
    });
  }
})();