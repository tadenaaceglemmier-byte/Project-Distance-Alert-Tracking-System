from django.contrib import admin

from .models import (
	Destination,
	DistanceAlert,
	LocationHistory,
	NotificationHistory,
	TrackingSession,
	UserProfile,
)


@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
	list_display = ("user", "phone", "created_at")
	search_fields = ("user__username", "user__email", "phone")


@admin.register(Destination)
class DestinationAdmin(admin.ModelAdmin):
	list_display = ("name", "owner", "latitude", "longitude", "updated_at")
	search_fields = ("name", "owner__username")
	list_filter = ("created_at",)


@admin.register(TrackingSession)
class TrackingSessionAdmin(admin.ModelAdmin):
	list_display = ("owner", "destination", "started_at", "ended_at")
	list_filter = ("started_at", "ended_at")
	search_fields = ("owner__username", "destination__name")


@admin.register(LocationHistory)
class LocationHistoryAdmin(admin.ModelAdmin):
	list_display = ("tracking_session", "latitude", "longitude", "distance_meters", "recorded_at")
	list_filter = ("recorded_at",)
	readonly_fields = ("tracking_session", "latitude", "longitude", "accuracy_meters", "distance_meters", "recorded_at")


@admin.register(DistanceAlert)
class DistanceAlertAdmin(admin.ModelAdmin):
	list_display = ("destination", "threshold_meters", "is_enabled", "is_armed")
	list_filter = ("is_enabled", "is_armed")


@admin.register(NotificationHistory)
class NotificationHistoryAdmin(admin.ModelAdmin):
	list_display = ("message", "tracking_session", "distance_meters", "created_at")
	list_filter = ("created_at",)
	readonly_fields = ("tracking_session", "alert", "distance_meters", "message", "created_at")
