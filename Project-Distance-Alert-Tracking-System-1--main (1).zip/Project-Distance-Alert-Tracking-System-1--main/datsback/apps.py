from django.apps import AppConfig


class DatsbackConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'datsback'
