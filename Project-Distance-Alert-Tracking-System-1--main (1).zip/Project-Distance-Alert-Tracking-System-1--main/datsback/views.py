import math

from django.contrib import messages
from django.contrib.auth import get_user_model, login
from django.contrib.auth.decorators import login_required
from django.db import IntegrityError, transaction
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils.timezone import now
from django.views.decorators.http import require_POST

from .forms import AlertForm, DestinationForm, ProfileForm, SignUpForm, UserUpdateForm
from .models import (
    Destination,
    DistanceAlert,
    LocationHistory,
    NotificationHistory,
    TrackingSession,
    UserProfile,
)
from .utils import distance_in_meters


User = get_user_model()


def signup(request):
    if request.user.is_authenticated:
        return redirect("dashboard")
    form = SignUpForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = form.save()
        UserProfile.objects.create(user=user)
        login(request, user)
        return redirect("dashboard")
    return render(request, "registration/signup.html", {"form": form})


@login_required
def dashboard(request):
    profile, _ = UserProfile.objects.get_or_create(user=request.user)
    active_session = (
        TrackingSession.objects.filter(owner=request.user, ended_at__isnull=True)
        .select_related("destination")
        .first()
    )
    latest_location = active_session.locations.first() if active_session else None
    destinations = Destination.objects.filter(owner=request.user).prefetch_related("alerts")
    notifications = NotificationHistory.objects.filter(
        tracking_session__owner=request.user
    ).select_related("alert__destination", "tracking_session")[:8]
    return render(
        request,
        "datsback/dashboard.html",
        {
            "profile": profile,
            "destinations": destinations,
            "destination_form": DestinationForm(),
            "alert_form": AlertForm(),
            "active_session": active_session,
            "latest_location": latest_location,
            "notifications": notifications,
        },
    )


@login_required
@require_POST
def add_destination(request):
    form = DestinationForm(request.POST)
    if form.is_valid():
        destination = form.save(commit=False)
        destination.owner = request.user
        destination.save()
        messages.success(request, "Destination saved.")
    else:
        messages.error(request, "Check the destination name and coordinates and try again.")
    return redirect("dashboard")


@login_required
@require_POST
def add_alert(request):
    destination = get_object_or_404(Destination, pk=request.POST.get("destination_id"), owner=request.user)
    form = AlertForm(request.POST)
    if form.is_valid():
        try:
            DistanceAlert.objects.create(
                destination=destination,
                threshold_meters=form.cleaned_data["threshold_meters"],
            )
            messages.success(request, "Distance alert added.")
        except IntegrityError:
            messages.error(request, "That distance alert already exists for this destination.")
    else:
        messages.error(request, "Choose an alert distance between 1 and 100,000 meters.")
    return redirect("dashboard")


@login_required
@require_POST
def toggle_alert(request, alert_id):
    alert = get_object_or_404(DistanceAlert, pk=alert_id, destination__owner=request.user)
    alert.is_enabled = not alert.is_enabled
    alert.is_armed = True
    alert.save(update_fields=["is_enabled", "is_armed"])
    return redirect("dashboard")


@login_required
@require_POST
def delete_destination(request, destination_id):
    destination = get_object_or_404(Destination, pk=destination_id, owner=request.user)
    destination.delete()
    messages.success(request, "Destination and its tracking history were removed.")
    return redirect("dashboard")


@login_required
def profile(request):
    profile_record, _ = UserProfile.objects.get_or_create(user=request.user)
    user_form = UserUpdateForm(request.POST or None, instance=request.user)
    profile_form = ProfileForm(request.POST or None, instance=profile_record)
    if request.method == "POST" and user_form.is_valid() and profile_form.is_valid():
        user_form.save()
        profile_form.save()
        messages.success(request, "Profile updated.")
        return redirect("profile")
    return render(
        request,
        "datsback/profile.html",
        {"user_form": user_form, "profile_form": profile_form},
    )


def _json_error(message, status=400):
    return JsonResponse({"ok": False, "error": message}, status=status)


@login_required
@require_POST
def start_tracking(request):
    destination = get_object_or_404(
        Destination, pk=request.POST.get("destination_id"), owner=request.user
    )
    try:
        with transaction.atomic():
            TrackingSession.objects.filter(
                owner=request.user, ended_at__isnull=True
            ).update(ended_at=now(), active_owner=None)
            tracking_session = TrackingSession.objects.create(
                owner=request.user, destination=destination
            )
            destination.alerts.update(is_armed=True)
    except IntegrityError:
        return _json_error("A tracking session is already running. Please retry.", status=409)
    return JsonResponse(
        {
            "ok": True,
            "session_id": tracking_session.pk,
            "destination": {
                "name": destination.name,
                "latitude": destination.latitude,
                "longitude": destination.longitude,
            },
        }
    )


@login_required
@require_POST
def stop_tracking(request):
    updated = TrackingSession.objects.filter(
        owner=request.user, ended_at__isnull=True
    ).update(ended_at=now(), active_owner=None)
    return JsonResponse({"ok": True, "stopped": bool(updated)})


@login_required
@require_POST
def update_location(request):
    try:
        latitude = float(request.POST.get("latitude", ""))
        longitude = float(request.POST.get("longitude", ""))
        accuracy_value = request.POST.get("accuracy", "")
        accuracy = float(accuracy_value) if accuracy_value else None
    except (TypeError, ValueError):
        return _json_error("Location coordinates must be valid numbers.")
    if not math.isfinite(latitude) or not -90 <= latitude <= 90:
        return _json_error("Latitude must be between -90 and 90 degrees.")
    if not math.isfinite(longitude) or not -180 <= longitude <= 180:
        return _json_error("Longitude must be between -180 and 180 degrees.")
    if accuracy is not None and (not math.isfinite(accuracy) or accuracy < 0):
        return _json_error("Location accuracy must be a non-negative number.")

    tracking_session = (
        TrackingSession.objects.filter(owner=request.user, ended_at__isnull=True)
        .select_related("destination")
        .first()
    )
    if tracking_session is None:
        return _json_error("Start a tracking session before sharing your location.", status=409)

    destination = tracking_session.destination
    distance = distance_in_meters(
        latitude,
        longitude,
        destination.latitude,
        destination.longitude,
    )
    LocationHistory.objects.create(
        tracking_session=tracking_session,
        latitude=latitude,
        longitude=longitude,
        accuracy_meters=accuracy,
        distance_meters=distance,
    )

    triggered_alerts = []
    for alert in destination.alerts.filter(is_enabled=True):
        if alert.is_armed and distance <= alert.threshold_meters:
            message = f"You are within {alert.threshold_meters:,} m of {destination.name}."
            NotificationHistory.objects.create(
                tracking_session=tracking_session,
                alert=alert,
                distance_meters=distance,
                message=message,
            )
            alert.is_armed = False
            alert.save(update_fields=["is_armed"])
            triggered_alerts.append(
                {"id": alert.pk, "threshold_meters": alert.threshold_meters, "message": message}
            )
        elif not alert.is_armed and distance > alert.threshold_meters * 1.15:
            alert.is_armed = True
            alert.save(update_fields=["is_armed"])

    return JsonResponse(
        {
            "ok": True,
            "latitude": latitude,
            "longitude": longitude,
            "accuracy": accuracy,
            "distance_meters": round(distance, 1),
            "alerts": triggered_alerts,
        }
    )