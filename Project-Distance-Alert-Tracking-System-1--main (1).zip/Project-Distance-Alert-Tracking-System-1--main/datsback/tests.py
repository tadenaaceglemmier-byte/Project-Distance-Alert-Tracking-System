from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from .models import (
    Destination,
    DistanceAlert,
    LocationHistory,
    NotificationHistory,
    TrackingSession,
)
from .utils import distance_in_meters


User = get_user_model()


class DistanceCalculationTests(TestCase):
    def test_identical_points_have_zero_distance(self):
        self.assertEqual(distance_in_meters(37.7749, -122.4194, 37.7749, -122.4194), 0)

    def test_one_degree_of_latitude_is_about_111_km(self):
        distance = distance_in_meters(0, 0, 1, 0)
        self.assertAlmostEqual(distance / 1000, 111.2, delta=0.2)


class TrackingWorkflowTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username="walker", password="A-strong-test-password-2026")
        self.other_user = User.objects.create_user(username="other", password="Another-strong-password-2026")
        self.destination = Destination.objects.create(
            owner=self.user,
            name="Market Street",
            latitude=37.7749,
            longitude=-122.4194,
        )
        self.client.force_login(self.user)

    def post_location(self, latitude, longitude):
        return self.client.post(
            reverse("update_location"),
            {"latitude": latitude, "longitude": longitude, "accuracy": 8},
        )

    def test_dashboard_requires_authentication(self):
        self.client.logout()
        response = self.client.get(reverse("dashboard"))
        self.assertRedirects(response, f"{reverse('login')}?next={reverse('dashboard')}")

    def test_user_cannot_start_tracking_another_users_destination(self):
        private_destination = Destination.objects.create(
            owner=self.other_user,
            name="Private place",
            latitude=0,
            longitude=0,
        )
        response = self.client.post(reverse("start_tracking"), {"destination_id": private_destination.pk})
        self.assertEqual(response.status_code, 404)
        self.assertFalse(TrackingSession.objects.exists())

    def test_location_update_requires_an_active_session(self):
        response = self.post_location(37.7749, -122.4194)
        self.assertEqual(response.status_code, 409)
        self.assertEqual(LocationHistory.objects.count(), 0)

    def test_location_is_saved_and_alert_fires_once_then_rearms(self):
        alert = DistanceAlert.objects.create(destination=self.destination, threshold_meters=500)
        self.client.post(reverse("start_tracking"), {"destination_id": self.destination.pk})

        first = self.post_location(37.777, -122.4194)
        self.assertEqual(first.status_code, 200)
        self.assertEqual(len(first.json()["alerts"]), 1)
        self.assertEqual(NotificationHistory.objects.count(), 1)

        still_near = self.post_location(37.777, -122.4194)
        self.assertEqual(still_near.json()["alerts"], [])
        self.assertEqual(NotificationHistory.objects.count(), 1)

        outside = self.post_location(37.784, -122.4194)
        self.assertEqual(outside.json()["alerts"], [])
        alert.refresh_from_db()
        self.assertTrue(alert.is_armed)

        returned = self.post_location(37.777, -122.4194)
        self.assertEqual(len(returned.json()["alerts"]), 1)
        self.assertEqual(NotificationHistory.objects.count(), 2)

    def test_invalid_coordinates_are_rejected(self):
        self.client.post(reverse("start_tracking"), {"destination_id": self.destination.pk})
        response = self.post_location(91, 0)
        self.assertEqual(response.status_code, 400)
        self.assertEqual(LocationHistory.objects.count(), 0)


class RegistrationTests(TestCase):
    def test_signup_creates_user_and_profile_and_logs_user_in(self):
        response = self.client.post(
            reverse("signup"),
            {
                "username": "newwalker",
                "email": "walker@example.com",
                "password1": "A-strong-test-password-2026",
                "password2": "A-strong-test-password-2026",
            },
        )
        self.assertRedirects(response, reverse("dashboard"))
        self.assertTrue(User.objects.filter(username="newwalker", profile__isnull=False).exists())
        self.assertIn("_auth_user_id", self.client.session)