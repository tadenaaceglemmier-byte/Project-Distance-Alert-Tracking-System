from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import UserCreationForm

from .models import Destination, UserProfile


User = get_user_model()


class SignUpForm(UserCreationForm):
    email = forms.EmailField()

    class Meta(UserCreationForm.Meta):
        model = User
        fields = ("username", "email")


class DestinationForm(forms.ModelForm):
    class Meta:
        model = Destination
        fields = ("name", "latitude", "longitude")
        widgets = {
            "latitude": forms.HiddenInput(),
            "longitude": forms.HiddenInput(),
        }


class AlertForm(forms.Form):
    threshold_meters = forms.IntegerField(min_value=1, max_value=100000, label="Alert distance (meters)")


class UserUpdateForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ("first_name", "last_name", "email")


class ProfileForm(forms.ModelForm):
    class Meta:
        model = UserProfile
        fields = ("phone",)