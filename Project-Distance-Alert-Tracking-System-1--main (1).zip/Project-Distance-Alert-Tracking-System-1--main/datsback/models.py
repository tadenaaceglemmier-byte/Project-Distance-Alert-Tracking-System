from django.conf import settings
from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models
from django.db.models import Q


coordinate_validators = [MinValueValidator(-90), MaxValueValidator(90)]
longitude_validators = [MinValueValidator(-180), MaxValueValidator(180)]


class UserProfile(models.Model):
	user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="profile")
	phone = models.CharField(max_length=30, blank=True)
	created_at = models.DateTimeField(auto_now_add=True)

	def __str__(self):
		return f"Profile for {self.user.username}"


class Destination(models.Model):
	owner = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="destinations")
	name = models.CharField(max_length=100)
	latitude = models.FloatField(validators=coordinate_validators)
	longitude = models.FloatField(validators=longitude_validators)
	created_at = models.DateTimeField(auto_now_add=True)
	updated_at = models.DateTimeField(auto_now=True)

	class Meta:
		ordering = ["-updated_at"]
		constraints = [
			models.CheckConstraint(condition=Q(latitude__gte=-90, latitude__lte=90), name="destination_latitude_valid"),
			models.CheckConstraint(condition=Q(longitude__gte=-180, longitude__lte=180), name="destination_longitude_valid"),
		]

	def __str__(self):
		return self.name


class TrackingSession(models.Model):
	owner = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="tracking_sessions")
	active_owner = models.OneToOneField(
		settings.AUTH_USER_MODEL,
		on_delete=models.CASCADE,
		null=True,
		blank=True,
		related_name="active_tracking_session",
	)
	destination = models.ForeignKey(Destination, on_delete=models.CASCADE, related_name="tracking_sessions")
	started_at = models.DateTimeField(auto_now_add=True)
	ended_at = models.DateTimeField(null=True, blank=True)

	class Meta:
		ordering = ["-started_at"]
	@property
	def is_active(self):
		return self.ended_at is None

	def save(self, *args, **kwargs):
		self.active_owner = self.owner if self.ended_at is None else None
		super().save(*args, **kwargs)

	def __str__(self):
		return f"{self.owner} tracking {self.destination}"


class LocationHistory(models.Model):
	tracking_session = models.ForeignKey(TrackingSession, on_delete=models.CASCADE, related_name="locations")
	latitude = models.FloatField(validators=coordinate_validators)
	longitude = models.FloatField(validators=longitude_validators)
	accuracy_meters = models.FloatField(null=True, blank=True, validators=[MinValueValidator(0)])
	distance_meters = models.FloatField(validators=[MinValueValidator(0)])
	recorded_at = models.DateTimeField(auto_now_add=True)

	class Meta:
		ordering = ["-recorded_at"]
		constraints = [
			models.CheckConstraint(condition=Q(latitude__gte=-90, latitude__lte=90), name="location_latitude_valid"),
			models.CheckConstraint(condition=Q(longitude__gte=-180, longitude__lte=180), name="location_longitude_valid"),
			models.CheckConstraint(condition=Q(distance_meters__gte=0), name="location_distance_nonnegative"),
		]


class DistanceAlert(models.Model):
	destination = models.ForeignKey(Destination, on_delete=models.CASCADE, related_name="alerts")
	threshold_meters = models.PositiveIntegerField(validators=[MinValueValidator(1), MaxValueValidator(100000)])
	is_enabled = models.BooleanField(default=True)
	is_armed = models.BooleanField(default=True)
	created_at = models.DateTimeField(auto_now_add=True)

	class Meta:
		ordering = ["threshold_meters"]
		constraints = [
			models.UniqueConstraint(fields=["destination", "threshold_meters"], name="unique_destination_alert_threshold"),
			models.CheckConstraint(condition=Q(threshold_meters__gte=1, threshold_meters__lte=100000), name="alert_threshold_in_range"),
		]

	def __str__(self):
		return f"{self.destination}: {self.threshold_meters} m"


class NotificationHistory(models.Model):
	tracking_session = models.ForeignKey(TrackingSession, on_delete=models.CASCADE, related_name="notifications")
	alert = models.ForeignKey(DistanceAlert, on_delete=models.CASCADE, related_name="notifications")
	distance_meters = models.FloatField(validators=[MinValueValidator(0)])
	message = models.CharField(max_length=180)
	created_at = models.DateTimeField(auto_now_add=True)

	class Meta:
		ordering = ["-created_at"]

	def __str__(self):
		return f"{self.message} at {self.created_at:%Y-%m-%d %H:%M}"
